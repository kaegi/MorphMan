v2.01

Please read http://rtkwiki.koohii.com/wiki/Morph_Man for up to date documentation.
